package com.example.story_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
